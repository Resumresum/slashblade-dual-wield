# 可选拔刀剑战斗兼容补丁 0.1.0

适用：Minecraft 26.1.2 Fabric、SlashBlade: Refabricated `26.1.2-1.5.1-Resharped-2.0.5`、Twilight Forest `4.9.768`、Fabric Loader ≥0.20.1、Java ≥25、MixinExtras ≥0.5.5。

退出游戏后，将本目录的 `slashblade-combat-compat-26.1.2-0.1.0.jar` 放入对应实例的 `mods`。不要把 `sources.jar` 装进游戏；它供查阅和修改源码使用。

此补丁改善敌对狼、铁傀儡、蜜蜂的索敌，以及暮色九头蛇真实部位的锁定和受击，保留原有中立保护、护甲、无敌与弱点规则。九头蛇身体或闭嘴头对低伤害单次攻击仍可能折算为 0。

双刀附属不依赖此补丁；没有安装暮色森林时，不要安装这个补丁。回退时退出游戏并移走补丁 JAR。

补丁适用 **LGPL-2.1-only**，完整条款见同目录 LICENSE，对应源码见 `slashblade-combat-compat-26.1.2-0.1.0-sources.jar`。双刀附属的自定义禁止收费条款不施加于本补丁本身。
